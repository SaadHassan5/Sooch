export default {
    light: 'SFProDisplay-Regular_1',//300
    regular: 'SFProDisplay-Regular_1',//400
    medium: 'SFProDisplay-Medium_1',//500
    semi_bold: 'SFProDisplay-Semibold_3',//600
    bold: 'SFProDisplay-Bold_1',//700
    boldItalic: 'Poppins-BoldItalic',//700
};